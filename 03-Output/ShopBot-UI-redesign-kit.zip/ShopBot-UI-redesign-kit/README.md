# ShopBot UI redesign kit

This handoff contains the editable ShopBot project source and a screenshot set of the customer chat and shop-owner interface. The PNG/JPEGs are saved local-preview captures from the October 2026 customer-experience checks; they are not fresh captures of a live WhatsApp account. The conversations use synthetic demo-shop data.

## Screens included

- Customer chat: English, Tamil and Tanglish, each at desktop and 390 px mobile widths.
- Shopping flow: product choices, list review and confirmation, voice entry, photo matching and photo review.
- Shop-owner interface: desktop/mobile conversation detail, inbox, request empty/sample states, and connections/usage controls.

A few owner-panel screenshots came from a saved preview containing an account email. In these copies, that one footer label is replaced with `owner@example.test`; the rest of the captured UI is unchanged.

## Where to redesign

The React UI is in `source/apps/dashboard/src/`:

- `NativeChat.tsx` — customer conversation, message composer, product cards and review actions.
- `ImageUploader.tsx` and `VoiceRecorder.tsx` — photo and voice entry controls.
- `OwnerDashboard.tsx` — shop conversation inbox, customer handling, requests and connection/usage views.
- `chat.css`, `owner.css`, `style.css` — customer, owner and shared styles.
- `customer-copy.ts` — translated English, Tamil and Tanglish interface copy.

The UI is served from `source/apps/dashboard/index.html`; `source/apps/server/src/http/native-test.ts` and `owner.ts` document the APIs the interface calls. Shared UI/data types live in `source/packages/contracts/`.

## Run locally

The project expects Node 22.12+ and PostgreSQL. From the `source/` directory, follow the setup in `README.md`; use only a disposable local database for preview work. Install dependencies with `npm ci`, then run `npm run build` to validate the edited UI and server. The README explains the local mock setup. No `node_modules`, live `.env`, database, API token or WhatsApp credentials are included in this ZIP.
